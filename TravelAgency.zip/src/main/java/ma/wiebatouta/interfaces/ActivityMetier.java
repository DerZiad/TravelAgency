package ma.wiebatouta.interfaces;

import ma.wiebatouta.models.Activite;

public interface ActivityMetier {
	public Activite getActivteById(Long id);
}
