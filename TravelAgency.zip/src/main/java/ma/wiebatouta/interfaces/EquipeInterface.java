package ma.wiebatouta.interfaces;

public interface EquipeInterface {

}
