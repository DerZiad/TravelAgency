package ma.wiebatouta.interfaces;

public interface HtmlMessage {

	public String getTopic();
	
	public String getTo();
	
	public String generateMessage();
	
	
	
}
