package ma.wiebatouta.filters;

import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSessionListener;

@WebListener
public class AuthenticationListner implements HttpSessionListener{
	
}
