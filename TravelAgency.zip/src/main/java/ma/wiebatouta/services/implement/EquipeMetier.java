package ma.wiebatouta.services.implement;

import ma.wiebatouta.interfaces.EquipeInterface;

public class EquipeMetier implements EquipeInterface{
	
}
