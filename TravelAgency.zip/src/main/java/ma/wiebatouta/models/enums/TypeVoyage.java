package ma.wiebatouta.models.enums;

public enum TypeVoyage {
	ACCOMPAGNE,CIRCUIT,FAMILIE,VOYAGE_SUR_MESURE;
}
