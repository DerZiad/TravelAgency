package ma.wiebatouta.models.enums;

public enum Difficulte {
	Facile,Moyenne,Difficile;
}
