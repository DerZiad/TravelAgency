package ma.wiebatouta.models.enums;

public enum TypePicture {
	HEADER,SIMPLE,TRAJET,BANNER;
}
