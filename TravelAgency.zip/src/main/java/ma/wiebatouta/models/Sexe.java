package ma.wiebatouta.models;

public enum Sexe {
	HOMME,FEMME;
}
