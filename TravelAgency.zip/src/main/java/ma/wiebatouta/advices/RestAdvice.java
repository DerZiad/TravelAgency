package ma.wiebatouta.advices;

import javax.servlet.annotation.HttpConstraint;

import org.springframework.web.bind.annotation.RestControllerAdvice;
