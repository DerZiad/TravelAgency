-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: localhost    Database: agence
-- ------------------------------------------------------
-- Server version	8.0.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `voyages`
--

DROP TABLE IF EXISTS `voyages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `voyages` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `age_max` int DEFAULT NULL,
  `age_min` int DEFAULT NULL,
  `date_arrivee` datetime NOT NULL,
  `date_depart` datetime NOT NULL,
  `description` varchar(600) NOT NULL,
  `destination` varchar(255) DEFAULT NULL,
  `nb_kilometres` double DEFAULT NULL,
  `nbr_personnes` int DEFAULT NULL,
  `nombre_personne_total` int NOT NULL,
  `prix` double NOT NULL,
  `reduction` double NOT NULL,
  `review` int NOT NULL,
  `titre` varchar(45) NOT NULL,
  `type_voyage` varchar(255) NOT NULL,
  `equipe_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKgxdhh3gnyyccwjo8vbmsdbtpa` (`equipe_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `voyages`
--

LOCK TABLES `voyages` WRITE;
/*!40000 ALTER TABLE `voyages` DISABLE KEYS */;
INSERT INTO `voyages` VALUES (3,50,10,'2022-12-31 00:00:00','2022-12-01 00:00:00','Venez découvrir les grands espaces vierges du Grand Nord et sa nuit polaire pour une expérience hors du commun','China',40,7,0,159,20,0,'Traineaux a chiens et aurores boreales ','ACCOMPAGNE',2),(4,60,12,'2022-04-26 00:00:00','2022-03-26 00:00:00','Les Eoliennes se composent de sept îles dont les plus célèbres sont Vulcano et Stromboli. Constituée d’un étonnant mélange de douceur de vivre, de beauté antique et de puissance sauvage, chaque île est un rocher volcanique que les hommes n’ont pas toujours réussi à domestiquer','Australia',100,11,0,1690,0,1,' Des Eoliennes aux terres volcaniques Etna ','ACCOMPAGNE',3),(5,60,18,'2022-01-31 00:00:00','2022-01-16 00:00:00','Plongez dans la magie de l\'hiver boréal au nord de la Suède dans une nature préservée et sauvage. Au programme, randonnées en ski Altaï, ','Netherlands',150,7,0,2680,0,3,' Dans les forêts de Laponie ','ACCOMPAGNE',7),(6,60,10,'2022-04-18 00:00:00','2022-03-18 00:00:00','La Laponie Suédoise est l’une des terres les plus sauvages d’Europe. En hiver, elle se pare de son blanc manteau, tandis que le ciel se couvre d’aurores boréales, le tout proposant un spectacle naturel jour et nuit à couper le souffle.','Turkey',50,16,0,21380,40,1,'Au pays des Carcajous ','ACCOMPAGNE',4),(7,60,2,'2022-04-05 00:00:00','2022-04-04 00:00:00','Chaque jour les courtes balades à vélo vous permettent de profiter de chaque moment en famille et prendre le temps de découvrir la région en toute sérénit','Netherlands',5,6,0,550,0,1,'La Hollande à vélo ','FAMILIE',8),(8,60,12,'2022-05-30 00:00:00','2022-04-30 00:00:00','Chaque printemps, la Hollande se pare de mille couleurs et laisse éclore des champs de tulipes à perte de vue. ','Netherlands',0,6,0,1850,0,1,'Vélo et péniche, les tulipes au fil de l’eau ','FAMILIE',5),(9,18,2,'2022-11-11 00:00:00','2022-10-10 00:00:00','Ce voyage à vélo relie la Hollande et la Belgique et vous fait découvrir les plus belles villes chargées d’histoire. ','Netherlands',50,6,0,850,0,1,' D\'Amsterdam à Bruges à vélo ','FAMILIE',4),(10,60,8,'2022-08-08 00:00:00','2022-07-07 00:00:00','Bergen, la \"capitale des fjords\" abrite \"les quais Bryggen\", magnifique quartier de maisons en bois rescapées de l’époque des marchands allemands de la Ligue Hanséatique','Brazil',15,15,0,860,0,1,' Hardangerfjord et Bergen ','VOYAGE_SUR_MESURE',5),(11,19,12,'2022-09-09 00:00:00','2022-08-08 00:00:00','De Bergen à Stavanger, ce voyage vous fait découvrir les randonnées les plus emblématiques des fjords du sud-ouest norvégien. ','Finland',180,10,0,1470,0,1,' Splendeurs du sud-ouest norvégien ','VOYAGE_SUR_MESURE',5),(12,40,10,'2022-01-31 00:00:00','2022-01-21 00:00:00','La montagne dans ce qu\'elle a de plus fascinant et technique.','France',300,25,0,178,0,0,'Voyage à paris','ACCOMPAGNE',3);
/*!40000 ALTER TABLE `voyages` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-01-14 17:40:13
